Import L_and_T_KW.robot in your Res folder
Import L_and_T.py in your Lib folder
Import L_and_T.robot in your Test suite folder 

After import, we need to update the lib/res file path accordingly along with chromedriver.exe path(NOTE:if driver path is not added in your Environmental Variables)

TC-1: to create random list and sort them
Using python module random, create a random number of elemnets in a list
sort the list elements using list sort function
return the sorted list
Develop Robot Framework Keyword using Python function and get the sorted list
From Testcase suite , get the Sorted list using the above created Keyword and pass or fail the tetscase

TC-2: create random list and square if element is even
Using python module random, create a random number of elemnets in a list
sort the list elements using list sort function
Navigate through each element of list and if it is even square it
The updated list  elements are placed in new list(res)
return the new sorted list
Develop Robot Framework Keyword using Python function and get the sorted list
From Testcase suite , get the Sorted list using the above created Keyword and pass or fail the tetscase

TC-3: to sort alaphabetical list elements and print the sorted elements
Using python ,sort the list elements using list sort function
return the sorted list
Develop Robot Framework Keyword using Python function and get the sorted list
From Testcase suite , get the Sorted list using the above created Keyword and pass or fail the tetscase

TC-4: to check the highest price camera is of canon brand or not
Using selenium webdriver in python, create a function which search for the product we need to search
It will check the highest price products
In the sorted product, it will check whether the it was the brand we are looking for or not
Develop Robot Framework Keyword using Python function  and return true or false
The testcase was designed that will print whether the specified is of highest price or not 
NOTE: we are not failing the testcase, just printing the details. If required we can fail if he python function returns False
