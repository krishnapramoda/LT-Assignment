import random
from selenium import webdriver
from selenium.webdriver.common.by import By
import time
def RandomSortedList(num, start=1, end=100):
    arr = []
    tmp = random.randint(start, end)
    for x in range(num):
        while tmp in arr:
            tmp = random.randint(start, end)
        arr.append(tmp) #add the random no. generated to the existing list
    arr.sort() #to sort the append list
    return arr
y=(RandomSortedList(5, 10, 50)) #randomsortedlist(number_of_ele,start range, end range)
print(y)

def square_even_numbers_in_list():
    res=[]
    for i in y:
        if i%2==0:
            res.append(i**2) #if ele is even it will sqaure and append it
        else:
            res.append(i)
    print(res)
square_even_numbers_in_list(y)

def Sorted_List(l):
    l.sort()
    for i in l:
        print(i)
l=["Pune","Bombay","Agra","Newyork","Bangalore"]
Sorted_List(l) #Calling function

def Fetch_Highest_Price_product(s,product_name):
    driver=webdriver.Chrome(executable_path="chromedriver.exe") #provide chromedriver path if it is not added to your PC path specifically
    driver.get("https://www.amazon.in/")
    driver.maximize_window()
    time.sleep(3)
    ser_box= driver.find_element(By.ID,"twotabsearchtextbox").send_keys(product_name)
    search_button = driver.find_element_by_id("nav-search-submit-text").click()
    time.sleep(5)
    sort_box= driver.find_element(By.ID,"a-autoid-0-announce")
    sort_box.click()
    price_sort = driver.find_element(By.LINK_TEXT,'Price: High to Low')
    price_sort.click()
    time.sleep(3)
    ele=driver.find_element_by_xpath("//div[@data-asin='B08X738Z4Z']")
    #ele.click()
    value=ele.text
    words=value.split()
    if s in words:
        print("Brand of Highest Price" + product_name + "is" + s)
        return True
    else:
        print("Brand of Highest Price"+ product_name +" is not "+ s)
        return False

#Fetch_Highest_Price_Camera("canon","Camera") Calling the function, will call from Robot Framework keyword